# Nandi Portfolio - Vercel Ready

This is a static HTML portfolio prepared for Vercel deployment.

## Vercel settings

- Framework Preset: Other
- Root Directory: ./
- Build Command: leave empty
- Output Directory: ./
- Install Command: leave empty or default

Main file: `index.html`
